#!/bin/bash
LOG=/var/lib/mpd/music/RAM/.update.log
ln -s $LOG /var/lib/mpd/music/.update.log


# version check
#if [ `jq '.revision' /var/lib/mpd/music/.version.json` -lt 19 ];then
##if [ `md5sum /boot/kernel7.img|grep "^b3361c90c81f534097bba828c550b834 "|wc -l` = 0 ];then
##  echo "your version is not supported." > $LOG
##  echo "version check successed" >> $LOG
##  exit
##fi

echo "( 1/10) stop services " > $LOG
systemctl stop mpd
systemctl stop shairport-sync
systemctl stop spotify-connect
systemctl stop spotifyd
systemctl stop pipe

# boot
echo "( 2/10) update /boot " > $LOG
#cp ./boot/* /boot/

# bin
echo "( 3/10) update /usr/local/bin " > $LOG
cp ./bin/* /usr/local/bin/

# configs
echo "( 4/10) update configs " > $LOG
#ENVFILE=/home/pi/configs/environment
#DEFAULT_SAMPLE=`grep ^DEFAULT_SAMPLE_FORMAT $ENVFILE`
#cp ./configs/* /home/pi/configs/
#sed -i -e "s/^DEFAULT_SAMPLE_FORMAT=.*$/$DEFAULT_SAMPLE/" $ENVFILE

# etc
echo "( 5/10) update /etc" > $LOG
#SPOTIFY_CONF=/etc/spotifyd.conf
#SPOTIFY_USR=`grep ^username $SPOTIFY_CONF`
#SPOTIFY_PWD=`grep ^password $SPOTIFY_CONF`
#cp ./etc/* /etc/
#sed -i -e "s/^username.*$/$SPOTIFY_USR/" $SPOTIFY_CONF
#sed -i -e "s/^password.*$/$SPOTIFY_PWD/" $SPOTIFY_CONF

# systemd
echo "( 6/10) update systemd configs" > $LOG
#cp ./system/* /lib/systemd/system/

# ympd update at next boot (rc.local)
echo "( 7/10) update misc" > $LOG
#cp ./misc/* /home/pi/misc/

# kernel update
echo "( 8/10) update kernel" > $LOG
#if [ `md5sum /boot/kernel7.img|grep "^00048c5a4f1122d30e5f2104cc3482aa"|wc -l` = 0 ];then
#  fileid=1h_aQT3TlY7SQLkZP8lezRZiTPEvi25rx
#  cd /run/
#  wget "https://drive.google.com/uc?export=download&id=${fileid}" -O smpd_v8_kernel.tar.gz
#  tar xzf /run/smpd_v8_kernel.tar.gz
#  cd /run/smpd_v8_kernel/
#  ./kernel_install.sh
#  cd /run/symphonic-mpd-update
#fi

# RTDM
echo "( 9/10) update drivers" > $LOG
modprobe -r rtalsa
modprobe -r xsink
cp ./drivers/* /lib/modules/4.14.52-smpd/kernel/drivers/xenomai/smpd/
modprobe rtalsa

# version
cp ./.version.json /var/lib/mpd/music/

echo "(10/10) restart services" > $LOG
systemctl daemon-reload
sync

systemctl start pipe
systemctl start mpd
#systemctl start shairport-sync
#systemctl start spotify-connect

echo "update successed" >> $LOG
